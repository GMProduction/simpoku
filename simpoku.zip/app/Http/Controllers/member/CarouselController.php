<?php

namespace App\Http\Controllers\Master;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Master\CarouselModel;

class CarouselController extends Controller
{
    //
    public function index(){
        

    }
}
