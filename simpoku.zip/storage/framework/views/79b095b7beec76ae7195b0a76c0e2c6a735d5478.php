<?php $__env->startSection('content'); ?>
    
<div class="container bawah">
    <div class="">
        <h3>Simpoku</h3>
        <p>Adalah sebuah website yang memberikan informasi seputar event - event yang berkaitan dengan kedokteran. 

        </p>
        <h5>Contact Person</h5>
        <p>0918123</p>
        <h5>Download apps</h5>
    </div>
</div>

<?php
    

    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => "http://api.rajaongkir.com/starter/city",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "GET",
      CURLOPT_HTTPHEADER => array(
        "key: 7366bbad708dcf7d2f1b3d69e5f4219f"
      ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    $listKota = array(); //bikin array untuk nampung list kota

    if ($err) {
      echo "cURL Error #:" . $err;
    } else {

        $arrayResponse = json_decode($response, true); //decode response dari raja ongkir, json ke array
      
        $tempListKota = $arrayResponse['rajaongkir']['results']; // ambil array yang dibutuhin aja, disini resultnya aja

        //looping array temporary untuk masukin object yang kita butuhin
        foreach ($tempListKota as $value) {
            //bikin object baru
            $kota = new stdClass();
            $kota->id = $value['city_id']; //id kotanya
            $kota->nama = $value['city_name']; //nama kotanya
            $kota->prov = $value['province']; //nama kotanya

            array_push($listKota, $kota); //push object kota yang kita bikin ke array yang nampung list kota

        }

        //$listKota : udah berisi list kota yang kita butuhin

        //ini untuk ngecek aja isi $list kota udah bener apa belum
        foreach ($listKota as $kota) {
          echo ("<br>");
          echo "id : ". $kota->id . " - " . "nama : ". $kota->nama;

        }
     

    }

?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program\web\New folder\simpoku\resources\views/main/about.blade.php ENDPATH**/ ?>