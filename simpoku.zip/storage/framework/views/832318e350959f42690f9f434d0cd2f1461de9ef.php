<section>
    Data Kosong

    <script>
    
    </script>
</section><?php /**PATH D:\Program\web\New folder\simpoku\resources\views/main/data/listEventKosong.blade.php ENDPATH**/ ?>