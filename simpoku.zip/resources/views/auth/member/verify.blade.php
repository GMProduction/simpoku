<center><h1>Welcome To Simpoku.com</h1></center>
Please Follow This <a href="{{ url('/verifyaccount/' . $remember_token) }}">Link</a> To Verify Your Simpoku Account and Get More Fitur From Simpoku.com.
<br>
Thank You For Joining With Us.
