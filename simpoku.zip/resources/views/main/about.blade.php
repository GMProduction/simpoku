@extends('main.header')

@section('content')
    
<div class="container bawah">
    <div class="">
        <h3>Simpoku</h3>
        <p>Adalah sebuah website yang memberikan informasi seputar event - event yang berkaitan dengan kedokteran. 

        </p>
        <h5>Contact Person</h5>
        <p>0918123</p>
        <h5>Download apps</h5>
    </div>
</div>



@endsection
